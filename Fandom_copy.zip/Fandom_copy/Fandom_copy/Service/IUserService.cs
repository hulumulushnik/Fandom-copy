﻿using Fandom_copy.DTOs.Auth;
using Fandom_copy.DTOs.Profile;
using Fandom_copy.Models;

namespace Fandom_copy.Services
{
    public interface IUserService
    {
        // --- Реєстрація / авторизація ---
        Task<ServiceResult<User>> RegisterAsync(RegisterRequestDto dto);
        Task<ServiceResult<User>> LoginAsync(LoginRequestDto dto);

        // --- Відновлення паролю (заглушка на майбутнє, TODO: відправка листа) ---
        Task<ServiceResult> RequestPasswordResetAsync(ForgotPasswordRequestDto dto);

        // --- Профіль ---
        Task<ServiceResult<UserProfileDto>> GetProfileAsync(Guid userId);
        Task<ServiceResult<UserProfileDto>> UpdateProfileAsync(Guid userId, UpdateProfileDto dto);
        Task<ServiceResult> ChangePasswordAsync(Guid userId, ChangePasswordDto dto);

        // --- Допоміжне: заблокувати/розблокувати користувача (знадобиться для Admin) ---
        Task<ServiceResult> SetBanStatusAsync(Guid userId, bool isBanned);
    }
}